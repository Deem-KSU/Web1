function validateForm() {

    var form = document.getElementById("joinTeamForm");

    var firstName = form.fName.value;
    var lastName = form.lName.value;
    var email = form.email.value;
    var dob = form.DOB.value;
    var area = form["Area-Expertise"].value;
    var skills = form.skills.value;
    var education = form.education.value;
    var message = form.message.value;
    var photoInput = form.photo;

    var errors = [];

   
    if (!firstName || !lastName || !email || !dob || !area || !skills || !education || !message || !photoInput.value) {
        errors.push("Please fill in all fields.");
    }

    
   if (firstName.search(/^\d/) !== -1 || lastName.search(/^\d/) !== -1) {
    errors.push("Names cannot start with a number.");
}

    
    if (education === "Choose Education Level") {
        errors.push("Please select an education level.");
    }

    
   
    if (photoInput.files.length === 0) {
        errors.push("Please upload a photo.");
    } 
    else {
        var fileName = photoInput.files[0].name.toLowerCase();

       
        if (fileName.search(/\.(jpg|jpeg|png|gif|webp)$/) === -1) {
            errors.push("Photo must be an image file (jpg, jpeg, png, gif, webp).");
        }
    }


     if (dob && dob > "2008-12-31") {
    errors.push("Date of birth must be 2008 or earlier.");
}


    if (errors.length > 0) {

        var messageText = "";
        for (var i = 0; i < errors.length; i++) {
            messageText += errors[i] + "\n";
        }

        alert(messageText);
        return false;
    }


    var fullName = firstName + " " + lastName;
    alert("Thank you, " + fullName + ". Your application has been submitted.");

    form.reset();
    document.getElementById("fileNameBox").style.display = "none";

    return false; 
}





function getFileName() {
    var input = document.getElementById('photo');
    var box = document.getElementById('fileNameBox');

    if (input.files.length > 0) {
        box.style.display = "block";
        box.textContent = input.files[0].name;
    } else {
        box.style.display = "none";
        box.textContent = "";
    }
}


